# ift6269_LDA
